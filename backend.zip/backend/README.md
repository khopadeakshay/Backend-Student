Here’s a sample `README.md` file for your project:

---

### README.md

# Student Backend Application

This is a backend application built using **Spring Boot** that allows the management of students and subjects, along with JWT-based authentication and role management (Student and Admin). The application utilizes an H2 in-memory database for storage.

## Features

- **Student Entity**: Allows for creating and managing students with attributes such as name and address.
- **Subject Entity**: Allows for creating and managing subjects.
- **JWT-based Authentication**: Secures endpoints with JWT tokens.
- **Roles**: Admin can manage students and subjects; students can view their information.
- **H2 Database**: An H2 in-memory database is used for storing the data.
- **RESTful APIs**: Exposes endpoints for managing students and subjects.

## Prerequisites

- **Java 19** or higher
- **Maven 3.8+**
- **Spring Boot** 2.x


The application will start on **port 9090**.

## API Endpoints

### Students

- **POST /api/students**: Create a new student.
- **GET /api/students**: Get a list of all students.
- **POST /api/students/{studentId}/subjects/{subjectId}**: Enroll a student to a subject.

### Subjects

- **POST /api/subjects**: Create a new subject.
- **GET /api/subjects**: Get a list of all subjects.

### Authentication

- **POST /login**: User login endpoint. Requires username and password in the body. Returns JWT token.
- **POST /register**: Register a new user (admin/student).

### Security

- The API is secured using JWT tokens.
- **Roles**: `ADMIN` (can create subjects and students) and `STUDENT` (can view their data and enroll in subjects).
- After successful login, the JWT token should be passed in the Authorization header as `Bearer <token>` for subsequent requests.

## H2 Console

You can access the H2 console at `http://localhost:9090/h2-console`. Use the following configuration:

- **JDBC URL**: `jdbc:h2:mem:testdb`
- **Username**: `sa`
- **Password**: `password`

## Configuration

The application can be configured via the `application.properties` file located in `src/main/resources`:

```properties
spring.application.name=StudentSubject
server.port=9090
# H2 database configuration
spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.driver-class-name=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=password

# Hibernate configuration
spring.jpa.hibernate.ddl-auto=update
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.H2Dialect

# Optional: Enable H2 Console
spring.h2.console.enabled=true
spring.h2.console.path=/h2-console
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

Feel free to modify or add more details to the `README.md` file as needed! Let me know if you'd like any further changes or additions.