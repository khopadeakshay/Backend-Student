package com.student.backend.model;

//this package contains all entity files for this project