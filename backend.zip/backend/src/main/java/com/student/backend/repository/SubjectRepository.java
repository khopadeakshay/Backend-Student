package com.student.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.student.backend.model.Subject;

public interface SubjectRepository extends JpaRepository<Subject, Long> {
}
